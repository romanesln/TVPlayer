package com.romane.tvplayer

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

/** Écran d'accueil de l'appli : saisie de la clé API Jellyfin (utilisée pour suivant/précédent). */
class SettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences(JellyfinPlaylist.PREFS, MODE_PRIVATE)
        val edit = findViewById<EditText>(R.id.edit_key)
        val status = findViewById<TextView>(R.id.txt_status)

        edit.setText(prefs.getString(JellyfinPlaylist.KEY_API, "") ?: "")
        status.text = if (edit.text.isNullOrBlank()) "Aucune clé enregistrée." else "Une clé est enregistrée."

        findViewById<Button>(R.id.btn_save).setOnClickListener {
            val value = edit.text.toString().trim()
            prefs.edit().putString(JellyfinPlaylist.KEY_API, value).apply()
            status.text = if (value.isEmpty()) {
                "Clé effacée."
            } else {
                "Clé enregistrée (${value.length} caractères)."
            }
        }

        FocusStyle.applyToChildren(findViewById<ViewGroup>(R.id.settings_root))
    }
}
