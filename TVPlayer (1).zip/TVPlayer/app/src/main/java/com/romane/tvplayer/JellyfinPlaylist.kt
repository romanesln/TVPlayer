package com.romane.tvplayer

import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Wholphin n'envoie au lecteur externe qu'un seul épisode. Pour permettre suivant/précédent,
 * on interroge le serveur Jellyfin à partir de l'adresse du flux (qui contient l'identifiant
 * de l'épisode et le jeton d'accès) afin de récupérer les autres épisodes de la série.
 */
object JellyfinPlaylist {

    class Item(val uri: Uri, val title: String)

    /** [items] contient tous les épisodes de la série, [currentIndex] est celui en cours. */
    class Resolved(val items: List<Item>, val currentIndex: Int)

    fun resolve(uri: Uri): Resolved {
        val segments = uri.pathSegments
        val idx = segments.indexOfFirst { it.equals("Videos", true) || it.equals("Items", true) }
        if (idx < 0 || idx + 1 >= segments.size) throw Exception("adresse de flux non reconnue")

        val idInUrl = segments[idx + 1]
        val prefix = segments.take(idx).joinToString("/")
        val base = "${uri.scheme}://${uri.authority}" + if (prefix.isEmpty()) "" else "/$prefix"
        val token = uri.getQueryParameter("api_key")
            ?: uri.getQueryParameter("ApiKey")
            ?: uri.getQueryParameter("X-Emby-Token")
            ?: throw Exception("jeton d'accès absent de l'adresse")

        val currentId = normalize(idInUrl)
        val itemJson = getJson("$base/Items?ids=$currentId&api_key=$token")
        val first = itemJson.getJSONArray("Items").optJSONObject(0)
            ?: throw Exception("épisode introuvable sur le serveur")
        val type = first.optString("Type")
        if (type != "Episode") throw Exception("ce n'est pas un épisode ($type)")
        val seriesId = first.optString("SeriesId")
        if (seriesId.isEmpty()) throw Exception("série introuvable")

        val episodes = getJson("$base/Shows/$seriesId/Episodes?api_key=$token").getJSONArray("Items")
        val dashed = idInUrl.contains('-')
        val original = uri.toString()
        val items = ArrayList<Item>()
        var currentIndex = -1
        for (i in 0 until episodes.length()) {
            val e = episodes.getJSONObject(i)
            val id = normalize(e.optString("Id"))
            if (id.isEmpty()) continue
            val season = e.optInt("ParentIndexNumber", 0)
            val number = e.optInt("IndexNumber", 0)
            val name = e.optString("Name")
            val title = "S${season}E$number · $name"
            val newUri = if (id == currentId) {
                uri
            } else {
                Uri.parse(original.replace(idInUrl, format(id, dashed), ignoreCase = true))
            }
            if (id == currentId) currentIndex = items.size
            items += Item(newUri, title)
        }
        if (currentIndex < 0) throw Exception("épisode en cours absent de la liste")
        return Resolved(items, currentIndex)
    }

    /** Décrit la forme de l'adresse sans afficher de valeurs secrètes (pour le diagnostic). */
    fun describe(uri: Uri): String {
        val path = uri.pathSegments.joinToString("/") {
            if (it.replace("-", "").length == 32) "<id>" else it
        }
        return "${uri.scheme}://${uri.host}/$path ? ${uri.queryParameterNames.joinToString(", ")}"
    }

    private fun normalize(id: String) = id.replace("-", "").lowercase()

    private fun format(id: String, dashed: Boolean): String {
        if (!dashed || id.length != 32) return id
        return "${id.substring(0, 8)}-${id.substring(8, 12)}-${id.substring(12, 16)}-" +
            "${id.substring(16, 20)}-${id.substring(20)}"
    }

    private fun getJson(url: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("Accept", "application/json")
        try {
            val code = c.responseCode
            if (code !in 200..299) throw Exception("le serveur répond HTTP $code")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }
}
