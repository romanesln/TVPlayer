plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.romane.tvplayer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.romane.tvplayer"
        minSdk = 24
        targetSdk = 34
        versionCode = 11
        versionName = "1.11"
    }

    // Clé de signature fixe : chaque nouvelle version se pose par-dessus l'ancienne
    // (sans désinstaller), donc la clé API Jellyfin et le décalage audio sont conservés.
    signingConfigs {
        create("fixed") {
            storeFile = file("tvplayer.keystore")
            storePassword = "tvplayer"
            keyAlias = "tvplayer"
            keyPassword = "tvplayer"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    val media3 = "1.4.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("androidx.core:core-ktx:1.13.1")
}
