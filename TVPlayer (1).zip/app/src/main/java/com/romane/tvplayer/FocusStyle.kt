package com.romane.tvplayer

import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat

/**
 * Rend l'élément sélectionné à la télécommande bien visible : cadre jaune épais, fond
 * translucide et agrandissement. Le cadre est dessiné par-dessus l'icône (sans la remplacer).
 */
object FocusStyle {

    /** Applique le style à tous les boutons situés sous [root] (root lui-même est ignoré). */
    fun applyToChildren(root: ViewGroup) {
        for (i in 0 until root.childCount) {
            apply(root.getChildAt(i))
        }
    }

    private fun apply(view: View) {
        // La barre de progression a son propre affichage de focus.
        val isTimeBar = view.javaClass.name.contains("TimeBar")
        if (!isTimeBar && view.isFocusable && view.isClickable) {
            view.foreground = ContextCompat.getDrawable(view.context, R.drawable.focus_ring)
            view.setOnFocusChangeListener { v, hasFocus ->
                val scale = if (hasFocus) 1.12f else 1f
                v.animate().scaleX(scale).scaleY(scale).setDuration(120).start()
            }
        }
        if (view is ViewGroup && !isTimeBar) {
            applyToChildren(view)
        }
    }
}
