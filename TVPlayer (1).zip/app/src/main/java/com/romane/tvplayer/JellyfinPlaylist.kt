package com.romane.tvplayer

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Wholphin n'envoie au lecteur externe qu'un seul épisode, sans jeton d'accès dans l'adresse.
 * Pour permettre suivant/précédent, on interroge le serveur Jellyfin (adresse du flux + clé API
 * saisie dans les réglages de TVPlayer) afin de récupérer les autres épisodes de la série.
 */
object JellyfinPlaylist {

    const val PREFS = "tvplayer"
    const val KEY_API = "jellyfin_api_key"
    const val KEY_BASE = "jellyfin_base_url"
    const val KEY_USER = "jellyfin_user_name"

    class Item(val uri: Uri, val title: String, val id: String)

    /** [items] contient tous les épisodes de la série, [currentIndex] est celui en cours. */
    class Resolved(
        val items: List<Item>,
        val currentIndex: Int,
        val base: String,
        val token: String?
    )

    /** Repère temporel fourni par Jellyfin : Intro, Recap, Preview, Outro (générique de fin)… */
    class Segment(val type: String, val startMs: Long, val endMs: Long)

    private class ApiException(val code: Int, message: String) : Exception(message)

    fun resolve(uri: Uri, savedKey: String?): Resolved {
        val segments = uri.pathSegments
        val idx = segments.indexOfFirst { it.equals("Videos", true) || it.equals("Items", true) }
        if (idx < 0 || idx + 1 >= segments.size) throw Exception("adresse de flux non reconnue")

        val idInUrl = segments[idx + 1]
        val prefix = segments.take(idx).joinToString("/")
        val base = "${uri.scheme}://${uri.authority}" + if (prefix.isEmpty()) "" else "/$prefix"
        val token = uri.getQueryParameter("api_key")
            ?: uri.getQueryParameter("ApiKey")
            ?: uri.getQueryParameter("X-Emby-Token")
            ?: savedKey?.trim()?.takeIf { it.isNotEmpty() }

        try {
            return resolveWith(uri, base, idInUrl, token, null)
        } catch (e: Exception) {
            // Certaines versions de Jellyfin exigent un identifiant utilisateur : on réessaie avec.
            if (token == null || (e is ApiException && e.code == 401)) throw e
            val userId = try {
                JSONArray(get(base, "/Users", "", token)).getJSONObject(0).getString("Id")
            } catch (_: Exception) {
                throw e
            }
            return resolveWith(uri, base, idInUrl, token, userId)
        }
    }

    private fun resolveWith(
        uri: Uri,
        base: String,
        idInUrl: String,
        token: String?,
        userId: String?
    ): Resolved {
        val currentId = normalize(idInUrl)
        val user = if (userId != null) "&userId=$userId" else ""

        val itemJson = JSONObject(get(base, "/Items", "ids=$currentId$user", token))
        val first = itemJson.getJSONArray("Items").optJSONObject(0)
            ?: throw Exception("épisode introuvable sur le serveur")
        val type = first.optString("Type")
        if (type != "Episode") throw Exception("ce n'est pas un épisode (type : $type)")
        val seriesId = first.optString("SeriesId")
        if (seriesId.isEmpty()) throw Exception("série introuvable")
        val firstSeriesName = first.optString("SeriesName")

        val episodes = JSONObject(
            get(base, "/Shows/$seriesId/Episodes", if (userId != null) "userId=$userId" else "", token)
        ).getJSONArray("Items")

        val original = uri.toString()
        val items = ArrayList<Item>()
        var currentIndex = -1
        for (i in 0 until episodes.length()) {
            val e = episodes.getJSONObject(i)
            val id = normalize(e.optString("Id"))
            if (id.isEmpty()) continue
            val season = e.optInt("ParentIndexNumber", 0)
            val number = e.optInt("IndexNumber", 0)
            val series = e.optString("SeriesName").ifEmpty { firstSeriesName }
            val title = displayTitle(series, season, number, e.optString("Name"))
            val newUri = if (id == currentId) uri else swapItem(original, currentId, id, token)
            if (id == currentId) currentIndex = items.size
            items += Item(newUri, title, id)
        }
        if (currentIndex < 0) throw Exception("épisode en cours absent de la liste")
        return Resolved(items, currentIndex, base, token)
    }

    /**
     * Adresse du flux d'un autre épisode : l'identifiant est remplacé partout (chemin et paramètres
     * comme mediaSourceId), avec ou sans tirets, et la clé API est ajoutée si l'adresse n'en contient pas.
     */
    private fun swapItem(original: String, oldId: String, newId: String, token: String?): Uri {
        var result = original
            .replace(format(oldId, true), format(newId, true), ignoreCase = true)
            .replace(oldId, newId, ignoreCase = true)
        if (token != null && !result.contains("api_key=", ignoreCase = true)) {
            result += (if (result.contains('?')) "&" else "?") + "api_key=" + Uri.encode(token)
        }
        return Uri.parse(result)
    }

    /** Ex. : « Seal Team - S1 E8 - L'échange ». */
    fun displayTitle(series: String, season: Int, number: Int, name: String): String {
        val parts = ArrayList<String>()
        if (series.isNotEmpty()) parts += series
        parts += "S$season E$number"
        if (name.isNotEmpty()) parts += name
        return parts.joinToString(" - ")
    }

    /**
     * Repères (intro, récapitulatif, générique de fin…) d'un épisode, via l'API « Media Segments »
     * de Jellyfin 10.10 et plus. Ils sont fournis par le serveur (plugin Intro Skipper, chapitres…).
     */
    fun segments(base: String, itemId: String, token: String?): List<Segment> {
        val json = JSONObject(get(base, "/MediaSegments/$itemId", "", token))
        val array = json.optJSONArray("Items") ?: return emptyList()
        val result = ArrayList<Segment>()
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            val start = o.optLong("StartTicks") / 10_000L
            val end = o.optLong("EndTicks") / 10_000L
            if (end > start) result += Segment(o.optString("Type"), start, end)
        }
        return result
    }

    /** Adresse de base du serveur (ex. http://192.168.1.75) déduite de l'adresse d'un flux. */
    fun baseUrl(uri: Uri): String? {
        val segments = uri.pathSegments
        val idx = segments.indexOfFirst { it.equals("Videos", true) || it.equals("Items", true) }
        if (idx < 0 || uri.authority == null) return null
        val prefix = segments.take(idx).joinToString("/")
        return "${uri.scheme}://${uri.authority}" + if (prefix.isEmpty()) "" else "/$prefix"
    }

    /** Vérifie la clé API auprès du serveur et renvoie un message lisible. */
    fun testKey(base: String, key: String, userName: String? = null): String {
        return try {
            val info = JSONObject(get(base, "/System/Info", "", key.trim()))
            val who = try {
                val u = user(base, key.trim(), userName)
                " Utilisateur : ${u.name}" +
                    if (u.count > 1 && userName.isNullOrBlank()) {
                        " (premier de ${u.count} : indique ton nom d'utilisateur si ce n'est pas le bon)."
                    } else {
                        "."
                    }
            } catch (e: Exception) {
                " Utilisateur : ${e.message}."
            }
            "Clé valide : serveur « ${info.optString("ServerName")} » (version ${info.optString("Version")})." + who
        } catch (e: ApiException) {
            if (e.code == 401 || e.code == 403) {
                "Clé refusée par le serveur (HTTP ${e.code}). Vérifie qu'elle est recopiée à l'identique (32 caractères)."
            } else {
                "Erreur : ${e.message}"
            }
        } catch (e: Exception) {
            "Serveur injoignable : ${e.message}"
        }
    }

    /** Décrit la forme de l'adresse sans afficher de valeurs secrètes (pour le diagnostic). */
    fun describe(uri: Uri): String {
        val path = uri.pathSegments.joinToString("/") {
            if (it.replace("-", "").length == 32) "<id>" else it
        }
        return "${uri.scheme}://${uri.host}/$path ? ${uri.queryParameterNames.joinToString(", ")}"
    }

    private fun normalize(id: String) = id.replace("-", "").lowercase()

    private fun format(id: String, dashed: Boolean): String {
        if (!dashed || id.length != 32) return id
        return "${id.substring(0, 8)}-${id.substring(8, 12)}-${id.substring(12, 16)}-" +
            "${id.substring(16, 20)}-${id.substring(20)}"
    }

    private fun get(base: String, path: String, params: String, token: String?): String =
        request("GET", base, path, params, token, null)

    private fun request(
        method: String,
        base: String,
        path: String,
        params: String,
        token: String?,
        body: String?
    ): String {
        val sb = StringBuilder(base).append(path)
        var separator = '?'
        if (params.isNotEmpty()) {
            sb.append('?').append(params)
            separator = '&'
        }
        if (token != null) sb.append(separator).append("api_key=").append(Uri.encode(token))

        val c = URL(sb.toString()).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("Accept", "application/json")
        if (token != null) {
            // La clé est envoyée de toutes les façons acceptées par Jellyfin (selon la version du serveur).
            c.setRequestProperty("X-Emby-Token", token)
            c.setRequestProperty(
                "Authorization",
                "MediaBrowser Client=\"TVPlayer\", Device=\"Fire TV\", DeviceId=\"tvplayer\", " +
                    "Version=\"1.12\", Token=\"$token\""
            )
        }
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        try {
            val code = c.responseCode
            if (code == 401 || code == 403) {
                throw ApiException(
                    code,
                    if (token == null) {
                        "clé API Jellyfin requise : ouvre TVPlayer depuis l'accueil de la Fire TV pour la saisir"
                    } else {
                        "clé API refusée par le serveur (HTTP $code)"
                    }
                )
            }
            if (code !in 200..299) throw ApiException(code, "le serveur répond HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    // ------------------------------------------------------------ Position de lecture

    /** Identifiant (32 caractères, sans tirets) de l'élément Jellyfin visé par une adresse de flux. */
    fun itemId(uri: Uri): String? {
        val segs = uri.pathSegments
        val i = segs.indexOfFirst { it.equals("Videos", true) || it.equals("Items", true) }
        if (i < 0 || i + 1 >= segs.size) return null
        val id = normalize(segs[i + 1])
        return if (id.length == 32) id else null
    }

    class User(val id: String, val name: String, val count: Int)

    private var cachedUser: User? = null
    private var cachedUserKey: String? = null

    /** Utilisateur Jellyfin concerné : celui qui porte [name], sinon le premier de la liste. */
    fun user(base: String, token: String, name: String?): User {
        val wanted = name?.trim().orEmpty()
        val cacheKey = "$base|$token|$wanted"
        cachedUser?.let { if (cachedUserKey == cacheKey) return it }
        val users = JSONArray(get(base, "/Users", "", token))
        if (users.length() == 0) throw Exception("aucun utilisateur trouvé")
        var chosen: JSONObject? = null
        if (wanted.isNotEmpty()) {
            for (i in 0 until users.length()) {
                val u = users.getJSONObject(i)
                if (u.optString("Name").equals(wanted, true)) chosen = u
            }
            if (chosen == null) throw Exception("utilisateur « $wanted » introuvable")
        } else {
            chosen = users.getJSONObject(0)
        }
        val result = User(chosen!!.getString("Id"), chosen.optString("Name"), users.length())
        cachedUser = result
        cachedUserKey = cacheKey
        return result
    }

    /** Position de reprise enregistrée par Jellyfin (0 si aucune). */
    fun serverPositionMs(base: String, token: String, userName: String?, itemId: String): Long {
        val u = user(base, token, userName)
        val item = JSONObject(get(base, "/Users/${u.id}/Items/$itemId", "", token))
        val data = item.optJSONObject("UserData") ?: return 0L
        return data.optLong("PlaybackPositionTicks") / 10_000L
    }

    /** Enregistre la position de lecture (apparaît dans « Reprendre la lecture » de Jellyfin et Wholphin). */
    fun reportPosition(base: String, token: String, userName: String?, itemId: String, positionMs: Long) {
        postUserData(
            base, token, userName, itemId,
            "{\"PlaybackPositionTicks\":${positionMs * 10_000L},\"LastPlayedDate\":\"${nowIso()}\"}"
        )
    }

    /** Marque l'épisode comme vu et efface la position de reprise. */
    fun markPlayed(base: String, token: String, userName: String?, itemId: String) {
        postUserData(
            base, token, userName, itemId,
            "{\"Played\":true,\"PlaybackPositionTicks\":0,\"LastPlayedDate\":\"${nowIso()}\"}"
        )
    }

    private fun postUserData(base: String, token: String, userName: String?, itemId: String, body: String) {
        val u = user(base, token, userName)
        try {
            // Jellyfin 10.10 et plus
            request("POST", base, "/UserItems/$itemId/UserData", "userId=${u.id}", token, body)
        } catch (e: ApiException) {
            if (e.code != 404 && e.code != 405) throw e
            // Versions plus anciennes
            request("POST", base, "/Users/${u.id}/Items/$itemId/UserData", "", token, body)
        }
    }

    private fun nowIso(): String {
        val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US)
        f.timeZone = java.util.TimeZone.getTimeZone("UTC")
        return f.format(java.util.Date())
    }
}
