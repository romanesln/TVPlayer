package com.romane.tvplayer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

@OptIn(UnstableApi::class)
class PlayerActivity : Activity() {

    private data class Entry(val uri: Uri, val title: String?)

    private lateinit var playerView: PlayerView
    private lateinit var delayPanel: View
    private lateinit var btnMinus: Button
    private lateinit var btnPlus: Button
    private lateinit var txtDelay: TextView
    private lateinit var txtTitle: TextView
    private lateinit var txtInfo: TextView
    private lateinit var txtMedia: TextView
    private lateinit var actionButtons: ViewGroup
    private lateinit var btnSkip: Button
    private lateinit var btnNextEp: Button

    private var player: ExoPlayer? = null
    private val delayProcessor = AudioDelayProcessor()
    private val handler = Handler(Looper.getMainLooper())
    private val hideTitle = Runnable { txtTitle.visibility = View.GONE }
    private val hideInfo = Runnable { txtInfo.visibility = View.GONE }
    private val hideMedia = Runnable {
        if (!playerView.isControllerFullyVisible) txtMedia.visibility = View.GONE
    }
    private var endedByCompletion = false

    // Si le module de décalage audio provoque une erreur, on le coupe et on reprend la lecture.
    private var delayEnabled = true
    private var currentItems: List<MediaItem> = emptyList()
    private var currentHeaders: Map<String, String> = emptyMap()

    // Données Jellyfin (titres, repères d'intro et de générique) une fois la série retrouvée.
    private var jfBase: String? = null
    private var jfToken: String? = null
    private var jfIds: List<String> = emptyList()
    private var titleList: List<String> = emptyList()
    private var segments: List<JellyfinPlaylist.Segment> = emptyList()
    private var segmentsReported = false
    private var skipTarget: JellyfinPlaylist.Segment? = null
    private val ticker = object : Runnable {
        override fun run() {
            updateActionButtons()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.player_view)
        delayPanel = findViewById(R.id.delay_panel)
        btnMinus = findViewById(R.id.btn_delay_minus)
        btnPlus = findViewById(R.id.btn_delay_plus)
        txtDelay = findViewById(R.id.txt_delay)
        txtTitle = findViewById(R.id.txt_title)
        txtInfo = findViewById(R.id.txt_info)
        txtMedia = findViewById(R.id.txt_media)
        actionButtons = findViewById(R.id.action_buttons)
        btnSkip = findViewById(R.id.btn_skip)
        btnNextEp = findViewById(R.id.btn_next_ep)

        // Surbrillance bien visible sur le bouton sélectionné à la télécommande.
        FocusStyle.applyToChildren(playerView)
        FocusStyle.applyToChildren(delayPanel as ViewGroup)
        FocusStyle.applyToChildren(actionButtons)

        btnSkip.setOnClickListener {
            val target = skipTarget
            val p = player
            if (target != null && p != null) {
                if (target.endMs >= p.duration && p.hasNextMediaItem()) {
                    p.seekToNextMediaItem()
                } else {
                    p.seekTo(target.endMs)
                }
                btnSkip.visibility = View.GONE
            }
        }
        btnNextEp.setOnClickListener {
            player?.seekToNextMediaItem()
            btnNextEp.visibility = View.GONE
        }

        delayProcessor.targetDelayMs = prefs().getInt(KEY_DELAY, 0)
        updateDelayLabel()

        btnMinus.setOnClickListener { changeDelay(-STEP_MS) }
        btnPlus.setOnClickListener { changeDelay(STEP_MS) }

        playerView.setShowSubtitleButton(true)
        playerView.setShowNextButton(true)
        playerView.setShowPreviousButton(true)
        playerView.controllerShowTimeoutMs = 5000
        // Sans animation : sinon Media3 fait glisser la barre de progression sur les boutons avant de masquer.
        playerView.setControllerAnimationEnabled(false)
        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { visibility ->
                val visible = visibility == View.VISIBLE
                delayPanel.visibility = if (visible) View.VISIBLE else View.GONE
                // Le titre du média s'affiche avec les commandes (ou quelques secondes à chaque épisode).
                if (visible && !txtMedia.text.isNullOrBlank()) {
                    txtMedia.visibility = View.VISIBLE
                } else if (!visible) {
                    txtMedia.visibility = View.GONE
                }
            }
        )

        handleIntent(intent)
        handler.postDelayed(ticker, 500)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    // ------------------------------------------------------------------ Intent

    private fun handleIntent(intent: Intent) {
        val entries = parsePlaylist(intent)
        Log.i(TAG, "Intent reçu : action=${intent.action} data=${intent.data} " +
            "type=${intent.type} extras=${intent.extras?.keySet()} éléments=${entries.size}")

        if (entries.isEmpty()) {
            releasePlayer()
            playerView.player = null
            txtTitle.text = getString(R.string.waiting)
            txtTitle.visibility = View.VISIBLE
            return
        }

        val data = intent.data
        val startIndex = if (data != null) {
            entries.indexOfFirst { it.uri == data }.coerceAtLeast(0)
        } else {
            0
        }
        val startPosition = if (intent.getBooleanExtra("from_start", false)) {
            0L
        } else {
            (intent.extras?.get("position") as? Number)?.toLong() ?: 0L
        }

        val mediaItems = entries.map { entry ->
            MediaItem.Builder()
                .setUri(entry.uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(entry.title).build())
                .build()
        }

        currentItems = mediaItems
        currentHeaders = parseHeaders(intent)
        jfBase = null
        jfToken = null
        jfIds = emptyList()
        titleList = emptyList()
        segments = emptyList()
        segmentsReported = false
        startPlayer(mediaItems, startIndex, startPosition)

        if (entries.size == 1) {
            // Un seul élément reçu : on cherche les autres épisodes sur le serveur Jellyfin.
            val uri = entries[0].uri
            if (uri.scheme == "http" || uri.scheme == "https") {
                val jellyfinPrefs = getSharedPreferences(JellyfinPlaylist.PREFS, MODE_PRIVATE)
                val savedKey = jellyfinPrefs.getString(JellyfinPlaylist.KEY_API, null)
                // On retient l'adresse du serveur pour pouvoir tester la clé depuis les réglages.
                JellyfinPlaylist.baseUrl(uri)?.let {
                    jellyfinPrefs.edit().putString(JellyfinPlaylist.KEY_BASE, it).apply()
                }
                Thread {
                    try {
                        val resolved = JellyfinPlaylist.resolve(uri, savedKey)
                        runOnUiThread { applyJellyfinPlaylist(resolved) }
                    } catch (e: Exception) {
                        Log.w(TAG, "Playlist Jellyfin indisponible", e)
                        // Pas de message à l'écran : suivant/précédent sont simplement absents.
                    }
                }.start()
            }
        }
    }

    /** Ajoute les épisodes précédents et suivants autour de l'épisode en cours, sans couper la lecture. */
    private fun applyJellyfinPlaylist(resolved: JellyfinPlaylist.Resolved) {
        val p = player ?: return
        if (p.mediaItemCount != 1) return

        fun toMediaItem(item: JellyfinPlaylist.Item) = MediaItem.Builder()
            .setUri(item.uri)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(item.title).build())
            .build()

        val before = resolved.items.subList(0, resolved.currentIndex).map { toMediaItem(it) }
        val after = resolved.items.subList(resolved.currentIndex + 1, resolved.items.size)
            .map { toMediaItem(it) }
        val current = p.getMediaItemAt(0)

        p.addMediaItems(after)
        p.addMediaItems(0, before)
        currentItems = before + current + after

        jfBase = resolved.base
        jfToken = resolved.token
        jfIds = resolved.items.map { it.id }
        titleList = resolved.items.map { it.title }
        showMediaTitle(titleList[resolved.currentIndex])
        loadSegments(resolved.currentIndex)
    }

    /**
     * Accepte les conventions courantes des lecteurs externes (MX Player / VLC) :
     * - data : l'URL à lire
     * - video_list : liste d'URL (Uri ou String) pour enchaîner les épisodes
     * - video_list.name / titles : titres associés
     */
    private fun parsePlaylist(intent: Intent): List<Entry> {
        val entries = mutableListOf<Entry>()
        val names = intent.getStringArrayExtra("video_list.name")
            ?: intent.getStringArrayExtra("titles")

        @Suppress("DEPRECATION")
        val parcels = try {
            intent.getParcelableArrayExtra("video_list")
        } catch (e: Exception) {
            null
        }
        if (parcels != null) {
            parcels.forEachIndexed { i, p ->
                (p as? Uri)?.let { entries += Entry(it, names?.getOrNull(i)) }
            }
        } else {
            var strings: Array<String>? = try {
                intent.getStringArrayExtra("video_list")
            } catch (e: Exception) {
                null
            }
            if (strings == null) {
                strings = intent.getStringArrayListExtra("playlist")?.toTypedArray()
            }
            strings?.forEachIndexed { i, s ->
                entries += Entry(Uri.parse(s), names?.getOrNull(i))
            }
        }

        val data = intent.data
        if (entries.isEmpty() && data != null) {
            entries += Entry(data, intent.getStringExtra("title"))
        }
        return entries
    }

    /** Les en-têtes HTTP sont transmis par paires clé/valeur dans l'extra "headers" (convention MX Player). */
    private fun parseHeaders(intent: Intent): Map<String, String> {
        val raw = intent.getStringArrayExtra("headers") ?: return emptyMap()
        val map = mutableMapOf<String, String>()
        var i = 0
        while (i + 1 < raw.size) {
            map[raw[i]] = raw[i + 1]
            i += 2
        }
        return map
    }

    // ------------------------------------------------------------------ Lecteur

    private fun startPlayer(items: List<MediaItem>, index: Int, positionMs: Long) {
        releasePlayer()
        val exo = createPlayer(currentHeaders)
        player = exo
        playerView.player = exo
        exo.setMediaItems(items, index, positionMs)
        exo.prepare()
        exo.playWhenReady = true
    }

    private fun describeError(error: PlaybackException): String {
        val sb = StringBuilder(error.errorCodeName)
        val c = error.cause
        if (c != null) {
            sb.append("\n").append(c.javaClass.simpleName).append(": ").append(c.message)
            c.stackTrace.take(4).forEach {
                sb.append("\n  ").append(it.className.substringAfterLast('.'))
                    .append('.').append(it.methodName).append(':').append(it.lineNumber)
            }
        }
        return sb.toString()
    }

    /** Titre du média en haut à droite (ex. « Seal Team - S1 E8 - L'échange »), quelques secondes. */
    private fun showMediaTitle(title: String) {
        txtMedia.text = title
        txtMedia.visibility = View.VISIBLE
        handler.removeCallbacks(hideMedia)
        handler.postDelayed(hideMedia, 6000)
    }

    /** Récupère auprès de Jellyfin les repères (intro, récapitulatif, générique de fin) de l'épisode. */
    private fun loadSegments(index: Int) {
        val base = jfBase ?: return
        val id = jfIds.getOrNull(index) ?: return
        val token = jfToken
        Thread {
            val found = try {
                JellyfinPlaylist.segments(base, id, token)
            } catch (e: Exception) {
                Log.w(TAG, "Repères indisponibles", e)
                emptyList()
            }
            runOnUiThread {
                if (player?.currentMediaItemIndex == index) {
                    segments = found
                }
            }
        }.start()
    }

    /** Affiche « Passer l'intro » et « Épisode suivant » au bon moment. */
    private fun updateActionButtons() {
        val p = player ?: return
        val position = p.currentPosition
        val duration = if (p.duration == C.TIME_UNSET) 0L else p.duration

        // Passer l'intro, le récapitulatif ou l'aperçu
        val skippable = segments.firstOrNull {
            (it.type.equals("Intro", true) || it.type.equals("Recap", true) ||
                it.type.equals("Preview", true)) &&
                position >= it.startMs && position < it.endMs - 1000
        }
        skipTarget = skippable
        if (skippable != null) {
            btnSkip.text = when {
                skippable.type.equals("Recap", true) -> "Passer le récapitulatif"
                skippable.type.equals("Preview", true) -> "Passer l'aperçu"
                else -> "Passer l'intro"
            }
            if (btnSkip.visibility != View.VISIBLE) {
                btnSkip.visibility = View.VISIBLE
                if (!playerView.isControllerFullyVisible) btnSkip.requestFocus()
            }
        } else if (btnSkip.visibility == View.VISIBLE) {
            btnSkip.visibility = View.GONE
        }

        // Épisode suivant : pendant le générique de fin (ou, à défaut de repère, les 45 dernières secondes)
        var showNext = false
        if (p.hasNextMediaItem()) {
            val outros = segments.filter { it.type.equals("Outro", true) }
            showNext = if (outros.isNotEmpty()) {
                outros.any { position >= it.startMs }
            } else {
                duration > 0 && duration - position in 1..45_000
            }
        }
        if (showNext && btnNextEp.visibility != View.VISIBLE) {
            btnNextEp.visibility = View.VISIBLE
            if (!playerView.isControllerFullyVisible && btnSkip.visibility != View.VISIBLE) {
                btnNextEp.requestFocus()
            }
        } else if (!showNext && btnNextEp.visibility == View.VISIBLE) {
            btnNextEp.visibility = View.GONE
        }
    }

    private fun showMessage(text: String, durationMs: Long = 15_000) {
        txtTitle.text = text
        txtTitle.visibility = View.VISIBLE
        handler.removeCallbacks(hideTitle)
        handler.postDelayed(hideTitle, durationMs)
    }

    private fun createPlayer(headers: Map<String, String>): ExoPlayer {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
            .setDefaultRequestProperties(headers)

        val renderers: DefaultRenderersFactory = if (delayEnabled) {
            object : DefaultRenderersFactory(this) {
                override fun buildAudioSink(
                    context: Context,
                    enableFloatOutput: Boolean,
                    enableAudioTrackPlaybackParams: Boolean
                ): AudioSink? {
                    return DefaultAudioSink.Builder(context)
                        .setEnableFloatOutput(false)
                        .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                        .setAudioProcessors(arrayOf<AudioProcessor>(delayProcessor))
                        .build()
                }
            }
        } else {
            DefaultRenderersFactory(this)
        }

        val exo = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .setAudioAttributes(AudioAttributes.DEFAULT, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setPreferredAudioLanguage("fr")
            .build()

        endedByCompletion = false
        exo.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val index = player?.currentMediaItemIndex ?: 0
                val title = titleList.getOrNull(index)
                    ?: mediaItem?.mediaMetadata?.title?.toString()
                if (!title.isNullOrBlank()) showMediaTitle(title)
                segments = emptyList()
                loadSegments(index)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    endedByCompletion = true
                    finish()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val p = player ?: return
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    p.seekToDefaultPosition()
                    p.prepare()
                } else {
                    Log.e(TAG, "Erreur de lecture", error)
                    val details = describeError(error)
                    if (delayEnabled) {
                        // Reprise sans le module de décalage audio, à la même position.
                        delayEnabled = false
                        val index = p.currentMediaItemIndex
                        val position = p.currentPosition
                        handler.post {
                            startPlayer(currentItems, index, position)
                            showMessage(
                                "Décalage audio désactivé (erreur interne). Détail :\n$details"
                            )
                        }
                    } else {
                        showMessage("Erreur de lecture :\n$details")
                    }
                }
            }
        })
        return exo
    }

    private fun releasePlayer() {
        player?.release()
        player = null
    }

    // ------------------------------------------------------------------ Décalage audio

    private fun changeDelay(delta: Int) {
        val value = (delayProcessor.targetDelayMs + delta).coerceIn(-MAX_DELAY_MS, MAX_DELAY_MS)
        delayProcessor.targetDelayMs = value
        prefs().edit().putInt(KEY_DELAY, value).apply()
        updateDelayLabel()
        // La valeur s'affiche dans le panneau en haut à droite : on ne masque pas l'image.
        if (!playerView.isControllerFullyVisible) {
            playerView.showController()
        }
    }

    private fun delayText(value: Int): String {
        val sign = if (value > 0) "+" else ""
        return "Décalage audio : $sign$value ms"
    }

    private fun updateDelayLabel() {
        txtDelay.text = delayText(delayProcessor.targetDelayMs)
    }

    private fun showInfo(text: String) {
        txtInfo.text = text
        txtInfo.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfo)
        handler.postDelayed(hideInfo, 1500)
    }

    private fun prefs() = getSharedPreferences("tvplayer", MODE_PRIVATE)

    // ------------------------------------------------------------------ Télécommande

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            val p = player
            val controllerVisible = playerView.isControllerFullyVisible
            when (event.keyCode) {
                KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_CHANNEL_UP -> {
                    p?.seekToNextMediaItem()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                    p?.seekToPreviousMediaItem()
                    return true
                }
                KeyEvent.KEYCODE_LEFT_BRACKET -> {
                    changeDelay(-STEP_MS)
                    return true
                }
                KeyEvent.KEYCODE_RIGHT_BRACKET -> {
                    changeDelay(STEP_MS)
                    return true
                }
                KeyEvent.KEYCODE_MENU -> {
                    playerView.showController()
                    btnPlus.requestFocus()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> if (!controllerVisible && p != null) {
                    p.seekBack()
                    showInfo("-10 s")
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> if (!controllerVisible && p != null) {
                    p.seekForward()
                    showInfo("+10 s")
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> if (!controllerVisible) {
                    playerView.showController()
                    return true
                }
                // Depuis la barre de progression, "Haut" monte vers le réglage du décalage audio.
                KeyEvent.KEYCODE_DPAD_UP -> if (controllerVisible && !delayPanel.hasFocus() &&
                    currentFocus?.javaClass?.name?.contains("TimeBar") == true
                ) {
                    btnPlus.requestFocus()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (playerView.isControllerFullyVisible) {
            playerView.hideController()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    /** Renvoie la position de lecture à l'application appelante (convention MX Player / VLC). */
    override fun finish() {
        val result = Intent()
        val p = player
        if (p != null) {
            val position = p.currentPosition
            val duration = if (p.duration == C.TIME_UNSET) 0L else p.duration
            result.putExtra("position", position.toInt())
            result.putExtra("duration", duration.toInt())
            result.putExtra("extra_position", position)
            result.putExtra("extra_duration", duration)
            result.putExtra("end_by", if (endedByCompletion) "playback_completion" else "user")
        }
        setResult(RESULT_OK, result)
        super.finish()
    }

    private companion object {
        const val TAG = "TVPlayer"
        const val KEY_DELAY = "audio_delay_ms"
        const val STEP_MS = 50
        const val MAX_DELAY_MS = 5000
        const val USER_AGENT = "VLC/3.0.20 LibVLC/3.0.20"
    }
}
